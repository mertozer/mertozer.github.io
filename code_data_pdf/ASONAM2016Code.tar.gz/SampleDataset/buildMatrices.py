import scipy.io
from scipy import sparse
from tld import get_tld
import twokenize
import numpy as np

uidDict = {}
uidIndex = 0
hashtagDict = {}
hashtagIndex = 0
urlDict = {}
urlIndex = 0
wordDict = {}
wordIndex = 0

rowX = []
colX = []
datX = []
rowH = []
colH = []
datH = []
rowH_c = []
colH_c = []
datH_c = []
rowD = []
colD = []
datD = []

with open('samplePosts.txt') as fi:
	next(fi)
	for line in fi:
		fields = line.rstrip('\r').rstrip('\n').split(';;;')
		uid = int(fields[0])
		tokens = twokenize.tokenize(fields[1])
		hashtags = fields[2].rstrip(']').lstrip('[').split(', ')
		urls = fields[3].rstrip(']').lstrip('[').split(', ')
		
		if not uid in uidDict:
			uidDict[uid] = uidIndex
			uidIndex += 1
			
		for token in tokens:
			if not token in wordDict:
				wordDict[token] = wordIndex
				wordIndex += 1
			rowX.append(uidDict[uid])
			colX.append(wordDict[token])
			datX.append(1.0)
		for hashtag in hashtags:
			if not hashtag in hashtagDict:
				hashtagDict[hashtag] = hashtagIndex
				hashtagIndex += 1
			rowH.append(uidDict[uid])
			colH.append(hashtagDict[hashtag])
			datH.append(1.0)
		for hashtag in hashtags:	
			for hashtag2 in hashtags:
				if not hashtag == hashtag2:
					rowH_c.append(hashtagDict[hashtag])
					colH_c.append(hashtagDict[hashtag2])
					datH_c.append(1.0)
		for url in urls:
			domain = get_tld(url, fail_silently=True)
			if not domain in urlDict:
				urlDict[domain] = urlIndex
				urlIndex += 1
			rowD.append(uidDict[uid])
			colD.append(urlDict[domain])
			datD.append(1.0)

C = np.zeros((len(uidDict),len(uidDict)),dtype = np.double)			

with open('endorsementNetwork.txt') as fi:
	next(fi)
	for line in fi:
		uid1,uid2,weight = line.rstrip('\r').rstrip('\n').split(';;;')
		C[uidDict[int(uid1)]][uidDict[int(uid2)]] = weight

gtComm = np.zeros((len(uidDict),1),dtype = np.double)
with open('labels.txt') as fi:
	next(fi)
	for line in fi:
		(uid, gtCommI) = line.rstrip('\r').rstrip('\n').split(';;;')
		gtComm[uidDict[int(uid)]] = int(gtCommI)

X = sparse.csr_matrix((datX, (rowX, colX)), shape=(max(rowX)+1, max(colX)+1))
H = sparse.csr_matrix((datH, (rowH, colH)), shape=(max(rowH)+1, max(colH)+1))
H_coo = sparse.csr_matrix((datH_c, (rowH_c, colH_c)), shape=(max(rowH_c)+1, max(colH_c)+1))
D = sparse.csr_matrix((datD, (rowD, colD)), shape=(max(rowD)+1, max(colD)+1))
scipy.io.savemat('matrices.mat', mdict={'X_uw': X, 'X_uh': H, 'H_coo':H_coo, 'X_ud':D, 'C':C, 'gtComm':gtComm})
