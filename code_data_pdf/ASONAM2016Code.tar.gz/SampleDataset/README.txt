SampleDataset/samplePosts.txt: 
	File containing posts in the format of uid;;;post;;;hashtags;;;urls.
	"uid" is the unique identifier for the user posted the post.
	"post" is the textual content.
	"hashtags" is the list of hashtags used in the post delimited by comma.
	"urls" is the list of urls used in the post delimited by comma.
SampleDataset/endorsementNetwork.txt:
	File containing user endorsement network in the format of edge list. Endorsements are treated as reciprocal.
SampleDataset/labels.txt:
	File containing the ground-truth communities in the format of uid;;;ground-truth-community
	"uid" is the unique identifier for the user
	"ground-truth-community" is the ground truth community label represented by integer.
	
SampleDataset/buildMatrices.py:
	Required packages: numpy, twokenize, tld, scipy
	It creates the matrices 
		X_uw (user-word matrix),
		X_uh (user-hashtag matrix),
		X_ud (user-domain matrix),
		C (adjacency matrix of user-user endorsement network),
		H_sim(H_coo) (hashtag co-occurence matrix)
	mentioned in the paper.

run.m:
	A Matlab script runs all three proposed methods for matrices created by python script "SampleDataset/buildMatrices.py".
	Predictied community assignments can be found in vectors of predComm_dual, predComm_tri and predComm_multi after running the script.
	Ground-Truth communities can be found in vector gtComm.
