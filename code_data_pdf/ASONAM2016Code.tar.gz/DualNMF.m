function [U, W, res] = DualNMF(X_uw, C, W_sim, U0, W0, alpha, beta, niter)
%X: User-Keyword Matrix
%C: User-User Connectivity Matrix
%W_sim: Keyword-Keyword Similarity Matrix
%U: user cluster representation
%W: keyword cluster representation
%alpha: user connectivity regularizer para
%beta: keyword similarity regularizer para

display('DualNMF');
trackRes = true % If you want to track the reconstruction error by each iteration.

res = 0;
res1 = [];
res2 = [];
resF = [];
res = 0;
U = U0;%rand(m,k);
W = W0;%rand(k,n);
minVal = 1e-5;
D_u = degree(C);
L_u = D_u - C;
D_v = degree(W_sim);
L_v = D_v - W_sim;
for it = 1:niter
    U = U.*sqrt((X_uw*W + alpha*C*U)./(max((U*W'*W + alpha*D_u*U),minVal)));
    W = W.*sqrt((X_uw'*U + beta*W_sim*W)./(max((W*U'*U+beta*D_v*W),minVal)));
    if trackRes
		res1Val = norm((X_uw - U*W'),'fro')^2;
		res2Val = alpha*trace(U'*L_u*U);
		res1 = [res1,res1Val];
		res2 = [res2,res2Val];
		resF = [resF, (res1Val + res2Val + beta*trace(W'*L_v*W))];
    end
end

if trackRes
	subplot(2,2,1)
	plot(res1)
	title('User x Keyword')

	subplot(2,2,2)
	plot(res2)
	title('User Connectivity')

	subplot(2,2,3)
	plot(resF)
	title('Full Residual')
end
res = norm(X_uw - U*W', 'fro')^2 + alpha*trace(U'*L_u*U) + beta*trace(W'*L_v*W);
end
