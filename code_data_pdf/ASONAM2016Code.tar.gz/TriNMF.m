function [U, W, H, res] = TriNMF(X_uh, X_uw, C, H_coo, W_sim, U0, H0, W0, alpha, gamma, beta, niter)
%X_uh: User-Hashtag Matrix
%X_uw: User-Keyword Matrix
%C: User-User Connectivity Matrix
%H_coo: Hashtag-Hashtag Co-occurence Matrix
%W_sim: Keyword-Keyword Similarity Matrix
%U: user cluster representation
%H: hashtag cluster representation
%W: keyword cluster representation
%alpha: user connectivity regularizer para
%gamma: hashtag cooccurence regularizer para
%beta: keyword similarity regularizer para

display('TriNMF');
trackRes = false; % If you want to track the reconstruction error by each iteration.

res1 = [];
res2 = [];
res3 = [];
resF = [];
U = U0;%rand(m,k);
H = H0;
W = W0;%rand(k,n);
minVal = 1e-5;
D_u = degree(C);
L_u = D_u - C;
D_v = degree(W_sim);
L_v = D_v - W_sim;
D_w = degree(H_coo);
L_w = D_w - H_coo;
for it = 1:niter
    U = sqrt(U.*sqrt((X_uh*H + X_uw*W + alpha*C*U)./(max((U*H'*H + U*W'*W + alpha*D_u*U),minVal))));
    H = sqrt(H.*sqrt((X_uh'*U + gamma*H_coo*H)./(max((H*U'*U + gamma*D_w*H),minVal))));
    W = sqrt(W.*sqrt((X_uw'*U + beta*W_sim*W)./(max((W*U'*U+beta*D_v*W),minVal))));
    if trackRes
		res1Val = norm((X_uw - U*W'),'fro')^2;
		res2Val = norm((X_uh - U*H'),'fro')^2;
		res3Val = alpha*trace(U'*L_u*U);
		res1 = [res1,res1Val];
		res2 = [res2,res2Val];
		res3 = [res3,res3Val];
		resF = [resF, (res1Val + res2Val + res3Val + gamma*trace(H'*L_w*H) + beta*trace(W'*L_v*W))];
    end
end

if trackRes
	subplot(2,2,1)
	plot(res1)
	title('User x Keyword')

	subplot(2,2,2)
	plot(res2)
	title('User x Hashtag')

	subplot(2,2,3)
	plot(res3)
	title('User Connectivity')

	subplot(2,2,4)
	plot(resF)
	title('Full Residual')
end
res = norm(X_uh - U*H', 'fro')^2 + norm(X_uw - U*W', 'fro')^2 + alpha*trace(U'*L_u*U) + gamma*trace(H'*L_w*H) + beta*trace(W'*L_v*W);
end
