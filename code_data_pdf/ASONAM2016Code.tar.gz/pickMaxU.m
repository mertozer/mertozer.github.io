function[communities] = pickMaxU(U)
    [numberOfElements, ~] = size(U);
    communities = zeros(numberOfElements,1)-1;
    for i = 1:numberOfElements
        [assignStrengthI,clusterI] = max(U(i,:));
        if(sum(U(i,:)) > 0)
            communities(i) = clusterI;
        else
            communities(i) = 0; %label of neutral
        end
    end
end