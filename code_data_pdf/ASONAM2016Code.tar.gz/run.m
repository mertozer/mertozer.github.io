load('Dataset/matrices.mat')
if ~issymmetric(C)
    C = C + C';
end
if ~issymmetric(H_coo)
    H_coo = H_coo + H_coo';
end
%% Parameters
k = 5; %Number of Communities
alpha = 100; %User Network Regularizer
beta = 1; %Word Similarity Regularizer
gamma = 1; %Hashtag Co-occurence Regularizer
theta = 1; %Domain Similarity Regularizer
niter = 100; %Iteration of updates

%% RUN
U0 = rand(size(X,1),k);
W0 = rand(size(X,2),k);
H0 = rand(size(H,2),k);
D0 = rand(size(D,2),k);
W_sim = squareform(1-pdist(X_uw','cosine'));
D_sim = squareform(1-pdist(X_ud','cosine'));
[U_dual,~,~] = DualNMF(X_uw, C, W_sim, U0, W0, alpha, beta, niter);
[U_tri,~,~,~] = TriNMF(X_uh, X_uw, C, H_coo, W_sim, U0, H0, W0, alpha, gamma, beta, niter);
[U_multi,~,~,~,~] = MultiNMF(X_uh, X_ud, X_uw, C, D_sim, H_coo, W_sim, U0, H0, D0, W0, alpha, theta, gamma, beta, niter);

predComm_dual = pickMaxU(U_dual);
predComm_tri = pickMaxU(U_tri);
predComm_multi = pickMaxU(U_multi);