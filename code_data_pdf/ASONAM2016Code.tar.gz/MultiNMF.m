function [U, W, H, D, res] = MultiNMF(X_uh, X_ud, X_uw, C, D_sim, H_coo, W_sim, U0, H0, D0, W0, alpha, theta, gamma, beta, niter)
%X_uh: User-Hashtag Matrix
%X_ud: User-Domain Matrix
%X_uw: User-Keyword Matrix
%C: User-User Connectivity Matrix
%H_coo: Hashtag-Hashtag Co-occurence Matrix
%D_sim: Domain-Domain Similarity Matrix
%W_sim: Keyword-Keyword Similarity Matrix
%U: user cluster representation
%H: hashtag cluster representation
%D: Domain cluster representation
%W: keyword cluster representation
%alpha: user connectivity regularizer para
%theta: domain similarity regularizer para
%gamma: hashtag cooccurence regularizer para
%beta: keyword similarity regularizer para

display('MultiNMF');
trackRes = false; % If you want to track the reconstruction error by each iteration.

res = 0;
res1 = [];
res2 = [];
res3 = [];
res4 = [];
resF = [];
U = U0;%rand(m,k);
H = H0;
D = D0;
W = W0;%rand(k,n);
minVal = 1e-5;
D_u = degree(C);
L_u = D_u - C;
D_v = degree(W_sim);
L_v = D_v - W_sim;
D_y = degree(D_sim);
L_y = D_y - D_sim;
D_w = degree(H_coo);
L_w = D_w - H_coo;
for it = 1:niter
    U = sqrt(U.*((X_uh*H + X_ud*D + X_uw*W + alpha*C*U)./(max((U*H'*H + U*D'*D + U*W'*W + alpha*D_u*U),minVal))));
    H = sqrt(H.*((X_uh'*U + gamma*H_coo*H)./(max((H*U'*U + gamma*D_w*H),minVal))));
    D = sqrt(D.*((X_ud'*U + theta*D_sim*D)./(max(D*U'*U + theta*D_y*D,minVal))));
    W = sqrt(W.*((X_uw'*U + beta*W_sim*W)./(max((W*U'*U+beta*D_v*W),minVal))));
    if trackRes
		res1Val = norm((X_uw - U*W'),'fro')^2;
		res2Val = norm((X_uh - U*H'),'fro')^2;
		res3Val = norm((X_ud - U*D'),'fro')^2;
		res4Val = alpha*trace(U'*L_u*U);
		res1 = [res1,res1Val];
		res2 = [res2,res2Val];
		res3 = [res3,res3Val];
		res4 = [res4,res4Val];
		resF = [resF, (res1Val + res2Val + res3Val + res4Val + gamma*trace(H'*L_w*H) + theta*trace(D'*L_y*D) + beta*trace(W'*L_v*W))];
    end
end

if trackRes
	subplot(2,3,1)
	plot(res1)
	title('User x Keyword')

	subplot(2,3,2)
	plot(res2)
	title('User x Hashtag')

	subplot(2,3,3)
	plot(res2)
	title('User x Domain')

	subplot(2,3,4)
	plot(res3)
	title('User Connectivity')

	subplot(2,3,5)
	plot(resF)
	title('Full Residual')
end
res = norm(X_uh - U*H', 'fro')^2 + norm(X_ud - U*D', 'fro')^2 + norm(X_uw - U*W', 'fro')^2 + alpha*trace(U'*L_u*U) + gamma*trace(H'*L_w*H) + theta*trace(D'*L_y*D) + beta*trace(W'*L_v*W);
end
