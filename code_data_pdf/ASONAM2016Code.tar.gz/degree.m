function [ D ] = degree( W )
%DEGREE
%   Returns degree of nodes in diagonal of given adjacency matrix W.
D = diag(sum(W));
end

