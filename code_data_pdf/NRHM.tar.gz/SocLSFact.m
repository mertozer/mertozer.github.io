function [Su, H, Sw, res] = SocLSFact(X, alpha, beta, gamma, ...
                                    Su0, Du, Sw0, M, H0, ...
                                    iter)
%%
% X: user-pair vs. sentiment words matrix.
% alpha: sentiment lexicon regularizer coefficient
% beta: prior positive interaction regularizer coefficient
% gamma: social balance regularizer coefficient
% Su0: initial polarities of links
% Du: diagonal matrix. 1's in the corresponding diagonal of links which has prior positive interaction, 0's otherwise
% Sw0: sentiment lexicon
% M: Social balance matrix
% H0: initial H matrix
% iter: number of iterations that multiplicative update rules want to be applied
calcRes = true;
res1 = [];
res2 = [];
res3 = [];
res4 = [];
resFull = [];
res = -1;

%% Initialization
Su = Su0;
H = H0;
Sw = Sw0;

%% Iterations
for n_iter = 1:iter
    
    deltaSw = 0;
    deltaSw_p = 0;
    deltaSw_n = 0;
    % Omit comments if if you want orthogonal Sw
    % deltaSw = Sw'*X'*Su*H-H'*(Su'*Su)*H-alpha*(Sw'*Sw)+alpha*Sw'*Sw0;
    % deltaSw_p = (abs(deltaSw)+deltaSw)/2;
    % deltaSw_n = (abs(deltaSw)-deltaSw)/2;
    
    %% Update Su, H, Sw
    Su = Su.*sqrt((X*Sw*H' + gamma*M*Su + beta*Du*Su0)./...
                    (max(Su*H*(Sw'*Sw)*H' + gamma*Su*(Su'*Su) + beta*Du*Su,1e-10)));
    H = H.*sqrt((Su'*X*Sw)./((Su'*Su)*H*(Sw'*Sw)));
    Sw = Sw.*sqrt((X'*Su*H + alpha*Sw0 + Sw*deltaSw_n)./...
                    (max(Sw*H'*(Su'*Su)*H + alpha*Sw + Sw*deltaSw_p,1e-10)));
   
    normal = diag(sum(Sw));
    Su = Su*normal';
    Sw = Sw*inv(normal);
    if calcRes
        res1_ = norm(X - Su*H*Sw','fro')^2;
        res2_ = alpha*norm(Sw - Sw0,'fro')^2;
        res3_ = gamma*norm(M - Su*Su','fro')^2;
        res4_ = beta*trace((Su-Su0)'*Du*(Su-Su0));
        
        res1 = [res1, res1_];
        res2 = [res2, res2_];
        res3 = [res3, res3_];
        res4 = [res4, res4_];
        res = res1_ + res2_ + res3_ + res4_;
        resFull = [resFull, res];
    end
    
end

if calcRes
    subplot(2,3,1)
    plot(res1)
    title('User x Keyword')
 
    subplot(2,3,2)
    plot(res2)
    title('Sentiment Word')
    
    subplot(2,3,3)
    plot(res3)
    title('Social Balance')
    
    subplot(2,3,4)
    plot(res4)
    title('Prior Positive')
    
    subplot(2,3,5)
    plot(resFull)
    title('Full')
end
end

