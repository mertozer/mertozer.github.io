function [Su, H, Sw, res] = SocLSFact_tempSmooth(eL,cL,X, alpha, beta, gamma, tau, ...
                                    Su0, Du, Su_prev, Sw0, M, H0, ...
                                    iter)
%%
% eL: array of indices of emerging links.
% cL: array of indices of continuing links.
% X: user-pair vs. sentiment words matrix.
% alpha: sentiment lexicon regularizer coefficient
% beta: prior positive interaction regularizer coefficient
% gamma: social balance regularizer coefficient
% tau: temporal smoothing regularizer
% Su0: initial polarities of links
% Du: diagonal matrix. 1's in the corresponding diagonal of links which has prior positive interaction, 0's otherwise
% Su_prev: previous snapshots' link polarities.
% Sw0: sentiment lexicon
% M: Social balance matrix
% H0: initial H matrix
% iter: number of iterations that multiplicative update rules want to be applied

calcRes = true;
res1 = [];
res2 = [];
res3 = [];
res4 = [];
res5 = [];
resFull = [];
res = -1;

%% Initialization
Su = Su0;
H = H0;
Sw = Sw0;

%% Pre-calculations for performance gain
M_eL_eL = M(eL,eL);M_cL_cL = M(cL,cL); X_cL = X(cL,:); X_eL = X(eL,:); 
Du_eL_eL = Du(eL,eL);Du_cL_cL = Du(cL,cL);
Su0_eL = Su0(eL,:);Su0_cL = Su0(cL,:);
Su_prev_cL = Su_prev(cL,:,:);

%% Iterations
for n_iter = 1:iter
    %% Temporal Smoothing
    smoothness = 0;
    markovC = 0;
    for s = 1:size(Su_prev,3)
        smoothness = smoothness + (1/exp(0.3*(size(Su_prev,3)-s)))*Su_prev_cL(:,:,s);
        if sum(sum(Su_prev_cL(:,:,s)))>0
            markovC = markovC + 1;
        end
    end
    
    deltaSw = 0;
    deltaSw_p = 0;
    deltaSw_n = 0;
    % Uncomment if you want orthogonal Sw
    % deltaSw = Sw'*X'*Su*H-H'*(Su'*Su)*H-alpha*(Sw'*Sw)+alpha*Sw'*Sw0;
    % deltaSw_p = (abs(deltaSw)+deltaSw)/2;
    % deltaSw_n = (abs(deltaSw)-deltaSw)/2;
    
    %% Emerging Links
    Su_eL = Su(eL,:);
    Su_eL = Su_eL.*sqrt((X_eL*Sw*H' + gamma*(M_eL_eL)*Su_eL + beta*Du_eL_eL*Su0_eL)./...
                    (max(Su_eL*H*(Sw'*Sw)*H' + gamma*Su_eL*(Su_eL'*Su_eL) + beta*Du_eL_eL*Su_eL,1e-10)));
    Su(eL,:) = Su_eL;
    %% Continuing Links
    if ~isempty(cL)
        Su_cL = Su(cL,:);
        Su_cL = Su_cL.*sqrt((X_cL*Sw*H' + tau*smoothness + gamma*(M_cL_cL)*Su_cL + beta*Du_cL_cL*Su0_cL)./...
                    (max(Su_cL*H*(Sw'*Sw)*H' + tau*markovC*Su_cL + gamma*Su_cL*(Su_cL'*Su_cL) + beta*Du_cL_cL*Su_cL,1e-10)));
        Su(cL,:) = Su_cL;
    end
    %% Update H,Sw
    H = H.*sqrt((Su'*X*Sw)./(Su'*Su*H*Sw'*Sw));
    Sw = Sw.*sqrt((X'*Su*H + alpha*Sw0 + Sw*deltaSw_n)./...
                    (max(Sw*H'*(Su'*Su)*H + alpha*Sw + Sw*deltaSw_p,1e-10)));
    normal = diag(sum(Sw));
    Su = Su*normal';
    Sw = Sw*inv(normal);
    if calcRes
        res1_ = norm(X - Su*H*Sw','fro')^2;
        res2_ = alpha*norm(Sw - Sw0,'fro')^2;
        res3_ = 0;
        for s = 1:size(Su_prev,3)
            res3_ = res3_ + tau*(1/exp((size(Su_prev,3)-s)))*norm(Su(cL,:) - Su_prev(cL,:,s),'fro')^2;
        end
        res4_ = beta*trace((Su-Su0)'*Du*(Su-Su0));
        res5_ = gamma*norm(M - Su*Su','fro')^2;
        res1 = [res1, res1_];
        res2 = [res2, res2_];
        res3 = [res3, res3_];
        res4 = [res4, res4_];
        res5 = [res5, res5_];
        res = res1_ + res2_ + res3_ + res4_ + res5_;
        resFull = [resFull, res];
    end
    
end

if calcRes
    subplot(2,3,1)
    plot(res1)
    title('User x Keyword')
 
    subplot(2,3,2)
    plot(res2)
    title('Sentiment Word')
 
    subplot(2,3,3)
    plot(res3)
    title('Snapshot Smoothness')
    
    subplot(2,3,4)
    plot(res4)
    title('Prior Positive')
    
    subplot(2,3,5)
    plot(res4)
    title('Social Balance')
    
    subplot(2,3,6)
    plot(resFull)
    title('Full')
end
end

