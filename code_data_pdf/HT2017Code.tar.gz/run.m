clear Su Sw res Su_init Sw_init

% For NMTF use alpha,beta,gamma = 0
% For SSMFLK use beta,gamma = 0
% For LSFact use gamma = 0
alphas = [0,0.1,1,10,100,1000]; %%NMTF
betas = [0,0.1,1,10,100,1000]; %%NMTF,SSMFLK
gammas = [0,0.1,1,10,100,1000]; %%NMTF,SSMFLK,LSFACT

iter = 100;
fs = [];
ps = [];
rs = [];
accs = [];

Su_init = Su0; %For SocLSFact and LSFact
%Su_init = rand(up,2) %For SSMLFK

Sw_init = Sw_star;
for alpha = alphas
    for beta = betas
        for gamma = gammas
            display(strcat(num2str(alpha),'_',num2str(beta),'_',num2str(gamma)));
            
            [Su,Sw,res] = SocLSFact(X,alpha,beta,gamma,...
                            Su_init,Du,Su0,Sw_init,Sw_star,...
                            M,eye(2),iter);
                        
            [ p, r, f, acc, ~ ] = evaluate(Su,userPairLabels);
            fs = [fs, f]; %F-Meas in predicting negative links
            ps = [ps, p]; %Precision in predicting negative links
            rs = [rs, r]; %Recall in predicting negative links
            accs = [accs, acc]; %Accuracy in predicting negative links
            
        end
    end
end

