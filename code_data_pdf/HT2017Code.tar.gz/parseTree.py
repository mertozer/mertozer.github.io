class parseTree:
	wordIndex = -1
	word = ''
	parent = -1
	children = []
	tag = ''
	visited = False # For traversing purposes
	negated = False
	def __init__(self, wordIndex, word, parent, children, tag, sentiment, negated):
		self.wordIndex = wordIndex
		self.word = word
		self.parent = parent
		self.children = children
		self.tag = tag
		self.visited = False
		self.negated = negated
		self.sentiment = sentiment
		self.but = False #Negated due to the "but rules"
		
	def addChild(self,node):
		self.children.append(node)
	
	def assignParent(self, node):
		self.parent = node
	
	def path(self,wordS,pathStr):
		if self.visited:
			return (False,'')
		else:
			self.visited = True
		
		pathStr = pathStr + ',' + self.tag + '{' + self.word + '}'
		
		if wordS == self.word:
			self.visited = False
			return (True, pathStr)
		
		for child in self.children:
			found, pathStrC = child.path(wordS, pathStr + ',-1')
			if found:
				self.visited = False
				return (found, pathStrC)
		
		if self.parent is not None:
			found, pathStrC = self.parent.path(wordS,pathStr + ',1')
			if found:
				self.visited = False
				return(found,pathStrC)
		
		self.visited = False
		return (False, '')	
	def hasAncestor(self,ancWord):
		if self.word == ancWord:
			return True
		else:
			if self.parent == None:
				return False
			else:
				return self.parent.hasAncestor(ancWord)
	def shortestPathToN(self,length):
		if self.visited:
			return (False, '', length)
		else:
			self.visited = True
		
		lengthTmp = length + 1
		
		if (self.tag == '^' or self.tag == 'N') and not length == 0:
			#self.visited = False
			return (True, self.word, lengthTmp)
		else:
			foundC = False
			foundP = False
			for child in self.children:
				foundC, wordC, lengthTmpC = child.shortestPathToN(lengthTmp)
			if self.parent is not None:
				foundP, wordP, lengthTmpP = self.parent.shortestPathToN(lengthTmp)
			
			if foundC and foundP:
				return (True, (wordC if lengthTmpC < lengthTmpP else wordP), (lengthTmpC if lengthTmpC < lengthTmpP else lengthTmpP))
			elif foundC:
				return (True, wordC, lengthTmpC)
			elif foundP:
				return (True, wordP, lengthTmpP)
		
		#self.visited = False
		return (False, '', -1)
		
	def __str__(self):
		string = 'NEG_' if self.negated else ''
		string += self.word + '{' + self.tag + '}:'
		string += '['
		for child in self.children:
			string += str(child)
		string += '],'
		return string
