#coding=utf-8
import psycopg2
import sys
import operator
import pdb
import codecs

### This script reads interactions between user pairs created by createUserPairIndices.py
### Reads number of retweets between user pairs matrix
### Reads user pair labels
### Create annotation task for human annotators

annotate = True

psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)
conn = psycopg2.connect(host = '###', port='###', user='###', password = '###', dbname='###')
conn.autocommit = True
cur = conn.cursor()

tweetSep = '|||'
userPairIndices = {}
userPairIndex = 0
with open('Matrices/userPairs.txt') as fi:
	for line in fi:
		user1,user2 = line.rstrip('\n').rstrip('\r').split(',')[0].split('<->')
		userPairIndices[(user1,user2)] = userPairIndex
		userPairIndex += 1

timeWindow = ['2017-01-01','2017-03-01']
fwLabels = open('Matrices/userPairLabels.txt','w')

userPairTweets = {}
userPairRetweets = {}
userPairMentionCounts = {}
for userPair in userPairIndices:
	userPairTweets[userPair] = ''
	userPairRetweets[userPair] = 0
	userPairMentionCounts[userPair] = 0
print(timeWindow[0])
len_ = float(len(userPairIndices))

## A sample SQL query which gathers all single mention interactions per user pair. You build your own based on your schema.
query = 'select screen_name_from, screen_name_to, string_agg(tweet,\''+ tweetSep + '\'), count(*) '
query += ' from user_mention M, tweet T '
query += ' where M.tid = T.tid '
query += ' and timestamp::date between \'' + timeWindow[0] + '\' and \'' + timeWindow[1] + '\''
query += ' and not screen_name_from = screen_name_to '
query += ' and tweet not like \'%@%@%\' ' #Double Mentions
query += ' and tweet not like \'%RT @%\'' #RTs
query += ' group by screen_name_from, screen_name_to'

cur.execute(query)
results = cur.fetchall()
for result in results:
	user1, user2, tweets, count_ = result
	if user1 > user2:
		user1, user2 = user2, user1
	if (user1,user2) in userPairTweets:
		if userPairTweets[(user1,user2)] == '':
			userPairTweets[(user1,user2)] += tweets.lower().replace('\r','').replace('\n','').replace(',','')
		else:
			userPairTweets[(user1,user2)] += tweetSep + tweets.lower().replace('\r','').replace('\n','').replace(',','')
		userPairMentionCounts[(user1,user2)] += count_

## A sample SQL query which gathers retweet counts between two users. You build your own based on your schema.
query = 'select screen_name_from, screen_name_to, count(*) from retweet R, tweet T '
query += ' where R.tid = T.tid '
query += ' and timestamp::date between \'' + timeWindow[0] + '\' and \'' + timeWindow[1] + '\''
query += ' and tweet like \'%RT @%\'' #RTs
query += ' group by screen_name_from, screen_name_to'
cur.execute(query)
results = cur.fetchall()
for result in results:
	user1, user2, count_ = result
	if user1 > user2:
		user1, user2 = user2, user1
	if (user1,user2) in userPairRetweets:
		userPairRetweets[(user1,user2)] += int(count_)

if annotate:
	fw = codecs.open('Annotation/' + timeWindow[0] + '_annotation.csv','w',encoding = 'utf-8')
	fw.write('annotate,rt_times,mention_times,tweets,user1,user2,userPairIndex\n')
fwTw = codecs.open('Tweets/tweets_' + timeWindow[0] + '.txt','w',encoding = 'utf-8')
fwCorrUP = open('Tweets/corrUP_' + timeWindow[0] + '.txt','w')
fwRT = open('Matrices/RT_' + timeWindow[0] + '.txt','w')
for userPair,count_ in sorted(userPairMentionCounts.iteritems(),key = operator.itemgetter(1), reverse = True):
	if count_ == 0:
		continue
	if annotate:
		fw.write(',' + str(userPairRetweets[userPair]) + ',' + str(userPairMentionCounts[userPair]) + ',' + userPairTweets[userPair] + ',' + userPair[0] + ',' + userPair[1]+ ',' + str(userPairIndices[userPair]) + '\r\n')
	tweets = userPairTweets[userPair].split(tweetSep)
	for tweet in tweets:
		fwTw.write(tweet +'\n')
		fwCorrUP.write(str(userPairIndices[userPair]) + '\n')
	fwRT.write(str(userPairIndices[userPair]+1) + ',1,' + str(0 if userPairRetweets[userPair] == 0 else 1) + '\n')
if annotate:
	fw.close()
fwTw.close()
fwCorrUP.close()
fwRT.close()

## A sample SQL query which gathers human annotated user pair labels, if there is any. You build your own based on your schema.
query = 'select screen_name_1, screen_name_2, label from user_pair_labels where timestamp_start = \'' + timeWindow[0] + '\''
cur.execute(query)
results = cur.fetchall()
for result in results:
	user1, user2, label = result
	if label == None:
		pdb.set_trace()
	if user1 > user2:
		user1, user2 = user2, user1
	if (user1,user2) in userPairIndices:
		fwLabels.write(str(userPairIndices[(user1,user2)]+1) + ',' + str(1) + ',' + str(label) + '\n')
fwLabels.close()
conn.close()
