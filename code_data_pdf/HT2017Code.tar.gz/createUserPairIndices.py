from collections import defaultdict
import psycopg2
import operator

conn = psycopg2.connect(host = '####', port='###', user='###', password = '###', dbname='###')
conn.autocommit = True
cur = conn.cursor()

with open('Matrices/userPairs.txt','w') as fw, open('Matrices/userGraph.txt','w') as fwG, open('Matrices/users.txt','w') as fwU, open('Matrices/userLabels.txt','w') as fwUL:
	userPairId = {}
	userPairCount = defaultdict(int)
	userIndices = {}
	userLabels = {}
	labelDict = {'Labour':1,'Conservative':2,'Scottish National Party':3,'Liberal Democrat':4,'Democratic Unionist Party':5}
	
	## A sample SQL query which gathers screen_names of interacting user pairs, their textual interaction, and their political labels. You build your own based on your schema.
	query = 'select screen_name_from, screen_name_to, tweet, L1.label, L2.label from user_mention M, user_label L1, user_label L2, tweet T '
	query += ' where M.tid = T.tid and screen_name_from = L1.screen_name and screen_name_to = L2.screen_name '
	query += ' and not L1.screen_name = L2.screen_name '
	query += ' and tweet not like \'%@%@%\' ' # Eliminate Double Mentions
	query += ' and tweet not like \'%RT @%\'' # Eliminate RTs
	query += ' and timestamp::date > \'2015-01-01\''
	cur.execute(query)
	results = cur.fetchall()
	for result in results:
		mentioner, mentioned, tweet, mentionerLabel, mentionedLabel = result
		userLabels[mentioner], userLabels[mentioned] = (mentionerLabel, mentionedLabel)
		mentioner, mentioned = (mentioner, mentioned) if mentioner < mentioned else (mentioned, mentioner)
		userPair = mentioner + '<->' + mentioned
		userPairCount[userPair] += 1
	pairIndex = 0
	userIndex = 0
	for userPair,count_ in sorted(userPairCount.iteritems(), key = operator.itemgetter(1), reverse = True):
		if count_ >= 3:
			user1, user2 = userPair.split('<->')
			if user1 not in userIndices:
				userIndices[user1] = userIndex
				userIndex += 1
			if user2 not in userIndices:
				userIndices[user2] = userIndex
				userIndex += 1
			fwG.write(str(userIndices[user1]) + ',' + str(userIndices[user2]) + ',' + str(count_) + '\n')
			fw.write(userPair + ',' + str(count_) + '\n')
			pairIndex += 1
		
	for user, index in sorted(userIndices.iteritems(), key = operator.itemgetter(1)):
		fwU.write(str(user) + '\n')
		fwUL.write(str(-1 if userLabels[user] not in labelDict else labelDict[userLabels[user]]) + '\n')
conn.close()
