function [Su, H, Sw, res] = DSentFact(X, alpha, beta, gamma, ...
                                    Su_init, Du, Su0, Sw_init, Sw0, M, H0, ...
                                    iter)
%   X: link(user-pair) x sentiment words
%   alpha: sentiment prior knowledge regularizer.
%   beta: link(user-pair) sign prior knowledge reguarizer.
%   gamma: social balance matrix regularizer.
%   Su_init,Su0: link(user-pair) x [-1,+1] prior probabilities of link between user pair.
%   Du: selected positive prior pairs as diagonal 1s, rest is 0.
%   Sw_init,Sw0: sentiment lexicon x [-1,+1] prior knowledge
%   M: Social balance matrix. Refer to the paper for details.
%   Su: link(user-pair) x [-1,+1]
%   Sw: sentiment lexicon x [-1,+1]

calcRes = true;
res1 = [];
res2 = [];
res3 = [];
res4 = [];
res5 = [];
resFull = [];
res = -1;
Su = Su_init;
H = H0;
Sw = Sw_init;

for n_iter = 1:iter
    n_iter
    %% For orthogonality
    deltaSu = 0;%Su'*X*Sw*H'-H*(Sw'*Sw)*H'+beta*Su'*Du*Su0-beta*Su'*Du*Su+gamma*Su'*M*Su-gamma*(Su'*Su);
    deltaSu_p = (abs(deltaSu)+deltaSu)/2;
    deltaSu_n = (abs(deltaSu)-deltaSu)/2;
    deltaSw = Sw'*X'*Su*H-H'*(Su'*Su)*H-alpha*(Sw'*Sw)+alpha*Sw'*Sw0;
    deltaSw_p = (abs(deltaSw)+deltaSw)/2;
    deltaSw_n = (abs(deltaSw)-deltaSw)/2;
    
    Su = Su.*sqrt((X*Sw*H' + gamma*(M)*Su + beta*Du*Su0 + Su*deltaSu_n)./...
                    (max(Su*H*(Sw'*Sw)*H' + gamma*Su*(Su'*Su) + beta*Du*Su + Su*deltaSu_p,1e-10)));
    
    H = H.*sqrt((Su'*X*Sw)./(Su'*Su*H*Sw'*Sw));
    Sw = Sw.*sqrt((X'*Su*H + alpha*Sw0 + Sw*deltaSw_n)./...
                    (max(Sw*H'*(Su'*Su)*H + alpha*Sw + Sw*deltaSw_p,1e-10)));
    normal = diag(sum(Sw));
    Su = Su*normal';
    Sw = Sw*inv(normal);
    if calcRes
        res1_ = norm(X - Su*H*Sw','fro')^2;
        res2_ = alpha*norm(Sw - Sw0,'fro')^2;
        res4_ = beta*trace((Su-Su0)'*Du*(Su-Su0));
        res5_ = gamma*norm(M - Su*Su','fro')^2;
        res1 = [res1, res1_];
        res2 = [res2, res2_];
        res4 = [res4, res4_];
        res5 = [res5, res5_];
        res = res1_ + res2_ + res4_ + res5_;
        resFull = [resFull, res];
    end
    
end

if calcRes
    subplot(2,3,1)
    plot(res1)
    title('User x Keyword')
 
    subplot(2,3,2)
    plot(res2)
    title('Sentiment Word')
 
    subplot(2,3,3)
    plot(res4)
    title('Prior Positive')
    
    subplot(2,3,4)
    plot(res4)
    title('Social Balance')
    
    subplot(2,3,5)
    plot(resFull)
    title('Full')
end
end

