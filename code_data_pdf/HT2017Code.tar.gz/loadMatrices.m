clear
timeIntervals = {'2017-01-01'};
userPairLabels = load('Matrices/userPairLabels.txt');
userPairLabels = full(spconvert(userPairLabels));

userPairCount = size(userPairLabels,1);
userPairs = load('Matrices/userGraph.txt')+1;
userPairs(:,3) = userPairs(:,3)-1;
userLabels = load('Matrices/userLabels.txt');
userGraph = spconvert(userPairs);
userGraph = [userGraph;zeros(length(userLabels)-size(userGraph,1),size(userGraph,2))];
userGraph = [userGraph,zeros(size(userGraph,1),length(userLabels)-size(userGraph,2))];
userGraph = userGraph + userGraph';


words = textscan(fopen('Matrices/words.txt','r'),'%[^\n]\n');
words = words{1,1};
up = length(userPairs);
w = length(words);

Du = [];
X = [];
Su0 = [];

for i = 1:length(timeIntervals)
    display(strcat('breakout-',num2str(i)));
    display('   Loading Du0...');
    Du0_ = full(spconvert(load(strcat('Matrices/RT_',timeIntervals{i},'.txt'))));
    [up_,~] = size(Du0_);
    if up_ < up %padding if sizes do not match
        Du0_ = [Du0_;zeros(up-up_,1)];
    end
    Du(:,:,i) = diag(Du0_);
    
    display('   Loading X...');
    X_ = load(strcat('Matrices/X_',timeIntervals{i},'.mat'));
    X(:,:,i) = X_.X;
    
    display('   Loading Su0...');
    Su0_ = [zeros(size(Du0_)),Du0_];
    random_init_links = find(sum(Su0_,2)==0 & sum(X(:,:,i),2)>0);
    Su0_(random_init_links,:) = repmat([0.5,0.5],length(random_init_links),1);
    Su0(:,:,i) = Su0_;
    
    display('   Building M...');
    nnzLinks = find(sum(X(:,:,i),2)>0)';
    for ppI = find(Du0_>0)'
        M(ppI,ppI,i) = 1;
        u1 = userPairs(ppI,1);u2 = userPairs(ppI,2); % Link u1-u2 positive prior
        for candI = nnzLinks
            M(candI,candI,i) = 1;
            for candJ = nnzLinks
                uc1 = userPairs(candI,1);uc2 = userPairs(candI,2);
                uc3 = userPairs(candJ,1);uc4 = userPairs(candJ,2);
                if (uc1 == u1 && uc3 == u2 && uc2 == uc4) || (uc1 == u1 && uc4 == u2 && uc2 == uc3)...
                   || (uc2 == u1 && uc3 == u2 && uc1 == uc4) || (uc2 == u1 && uc4 == u2 && uc1 == uc3)...
                   || (uc3 == u1 && uc1 == u2 && uc2 == uc4) || (uc3 == u1 && uc2 == u2 && uc1 == uc4) ...
                    || (uc4 == u1 && uc1 == u2 && uc2 == uc3) || (uc4 == u1 && uc2 == u2 && uc1 == uc3)
                    M(candI,candJ,i) = 1;
                    M(candJ,candI,i) = 1;
                end
                  
            end
        end
    end
end


%% Non-Labeled Pairs Elimination
labeled = repmat(false,size(userPairs,1),1);
for t = 1:size(X,3)
    labeled = labeled | userPairLabels(:,t)~=0;
end
labeled = find(labeled);
Su0 = Su0(labeled,:,:);
Du = Du(labeled,labeled,:);
M = M(labeled,labeled,:);
userPairCount = length(labeled);
userPairLabels = userPairLabels(labeled,:);
userPairs = userPairs(labeled,:);
X = X(labeled,:,:);

%% L1 Normalization
for i = 1:length(timeIntervals)
    X(:,:,i) = sparse(X(:,:,i)/norm(X(:,:,i),1));
    Su0(:,:,i) = sparse(Su0(:,:,i)/norm(Su0(:,:,i)',1));
    Du(:,:,i) = sparse(Du(:,:,i)/norm(Du(:,:,i)',1));
    M(:,:,i) = sparse(M(:,:,i)/norm(M(:,:,i)',1));
end

load('Matrices/Sw_star.mat');
Sw_star = Sw_star/norm(Sw_star',1);


timeSnap = length(timeIntervals);
wordCount = size(Sw_star,1);
clear m n i X_ Du0_ Su0_ random_init_links t_iter i up_ w userPairI val j k ...
    uc1 uc2 uc3 uc4 u1 u2 t nnzLinks ppI candI candJ
