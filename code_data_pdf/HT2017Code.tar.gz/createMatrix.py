import sys
import pdb
import json
import re
import numpy as np
from scipy.io import savemat
import operator
import codecs
from parseTree import parseTree
import matplotlib.pyplot as plt
from nltk.stem import WordNetLemmatizer
from nltk.corpus import wordnet

wordnet_lemmatizer = WordNetLemmatizer()
sentWords = {}
sentWordsInd = {}
sentWordIndex = 0
targets = {}
targetsUid = {}
posters = {}

def tweeboPOSToWordnetPOS(tweebo):
	if tweebo == 'N' or tweebo == 'O' or tweebo == 'S' or tweebo == '^'\
		or tweebo == 'Z' or tweebo == 'L' or tweebo == 'M':
		return wordnet.NOUN
	elif tweebo == 'V':
		return wordnet.VERB
	elif tweebo == 'A':
		return wordnet.ADJ 
	elif tweebo == 'R':
		return wordnet.ADV
	
	return -1

try:
	with codecs.open('lemmaDict.json',encoding = 'utf-8') as fi:
		lemmaDict = json.load(fi)
except IOError:
	lemmaDict = {}
	
descriptorStr = ''
NEGATION = r"""
    (?:
        ^(?:never|no|nothing|nowhere|noone|none|not|
            haven't|hasnt|hadn't|can't|couldn't|shouldn't|
            won't|wouldn't|don't|doesn't|didn't|isn't|aren't|ain't
        )$
    )
    |
    n't"""
NEGATION_RE = re.compile(NEGATION, re.VERBOSE)

userPair = {}
userPairInd = {}
tweetPairIndices = {}
breakouts = ['2017-01-01']
with open('Matrices/userPairs.txt') as fi:
		pairIndex = 0
		for line in fi:
			user1, user2 = line.rstrip('\n').rstrip('\r').split(',')[0].split('<->')
			userPair[(user1,user2)] = pairIndex
			userPairInd[pairIndex] = (user1,user2)
			pairIndex += 1
with open('Glossary/positive-words.txt') as fi:
	for line in fi:
		word = line.rstrip('\r').rstrip('\n')
		if word.startswith('#'): #Manually added to skip positive words such as trump
			continue
		sentWords[word] = 1
		sentWordsInd[word] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word] = -1
		sentWordsInd['not_' + word] = sentWordIndex
		sentWordIndex += 1
		sentWords[word + '_but'] = -1
		sentWordsInd[word + '_but'] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word + '_but'] = 1
		sentWordsInd['not_' + word + '_but'] = sentWordIndex
		sentWordIndex += 1
with open('Glossary/negative-words.txt') as fi:
	for line in fi:
		word = line.rstrip('\r').rstrip('\n')
		if word.startswith('#'): #Manually added to skip negative words such as conservative, issues, radical
			continue
		sentWords[word] = -1
		sentWordsInd[word] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word] = 1
		sentWordsInd['not_' + word] = sentWordIndex
		sentWordIndex += 1
		sentWords[word + '_but'] = 1
		sentWordsInd[word + '_but'] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word + '_but'] = -1
		sentWordsInd['not_' + word + '_but'] = sentWordIndex
		sentWordIndex += 1
with open('Glossary/emoticons.txt') as fi:
	for line in fi:
		wordAndSent = line.rstrip('\r').rstrip('\n').split('\t')
		word = wordAndSent[0]
		sentimentScore = int(wordAndSent[1])
		if word in sentWords or sentimentScore == 0:
			continue
		sentWords[word] = sentimentScore
		sentWordsInd[word] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word] = sentimentScore*-1
		sentWordsInd['not_' + word] = sentWordIndex
		sentWordIndex += 1
		sentWords[word + '_but'] = sentimentScore*-1
		sentWordsInd[word + '_but'] = sentWordIndex
		sentWordIndex += 1
		sentWords['not_' + word + '_but'] = sentimentScore
		sentWordsInd['not_' + word + '_but'] = sentWordIndex
		sentWordIndex += 1

Sw_star = np.zeros((sentWordIndex,2))

with open('Matrices/words.txt','w') as fw:
	for word in sentWordsInd:
		if sentWords[word] == -1:
			Sw_star[sentWordsInd[word]][0] = 1
		elif sentWords[word] == 1:
			Sw_star[sentWordsInd[word]][1] = 1
		else:
			print('This should not happen')
	wordIndexPrev = -1
	for word, wordIndex in sorted(sentWordsInd.iteritems(), key = operator.itemgetter(1)):
		if wordIndex == wordIndexPrev:
			# To handle order of compositions. Assumption: hard_work and work_hard has the same sentiment and sentiment word index.
			continue
		fw.write(word + '\n')
		wordIndexPrev = wordIndex

savemat('Matrices/Sw_star.mat',{'Sw_star':Sw_star})

print('Sentiment Corpus: ' + str(sentWordIndex) + ' words')
for i in range(len(breakouts)):
	X = np.zeros((len(userPair),len(sentWords)))
	tweets = []
	with codecs.open('Tweets/tweets_' + breakouts[i] + '.txt',encoding = 'utf-8') as fi:
		for line in fi:
			tweets.append(line.rstrip('\r').rstrip('\n'))

	
	with open('Tweets/corrUP_' + breakouts[i] + '.txt') as fi:
		index = 0
		for line in fi:
			pairIndex = int(line.rstrip('\r').rstrip('\n'))
			target1,target2 = userPairInd[pairIndex]
			tweetPairIndices[index] = pairIndex
			targets[index] = (target1.lower(),target2.lower())
			index += 1

	

	tweetParse = {}
	nodes = {}

	tweetIndex = 0
	negateNext = False
	
	fParse = open('Tweets/tweets_' + breakouts[i] + '.txt.predict')
	tweetCount = 0.0
	for line in fParse:
		if line == '\n':
			tweetCount += 1.0
	fParse.close()
	fParse = codecs.open('Tweets/tweets_' + breakouts[i] + '.txt.predict',encoding = 'utf-8')
	for line in fParse:
		if line == '\n':
			sys.stdout.write(str(tweetIndex/tweetCount) + '\r')
			#Tweet Ends
			
			pairIndex = tweetPairIndices[tweetIndex]
			
			######################
			## Build Parse Tree ##
			######################
			for word in tweetParse:
				if tweetParse[word]['rel'] > 0:
					for parentCand in nodes:
						if nodes[parentCand].wordIndex == tweetParse[word]['rel']:
							nodes[parentCand].addChild(nodes[word])
							nodes[word].assignParent(nodes[parentCand])
							
			if targets[tweetIndex][0] in nodes:
				mentioned = targets[tweetIndex][0] 
			elif targets[tweetIndex][1] in nodes:
				mentioned = targets[tweetIndex][1]
			else:
				print('This should not happen 2')
				tweetParse = {}
				nodes = {}
				tweetIndex += 1
				continue
			################################
			## Sent-Word Level Prediction ##
			################################
			for wordId in nodes:
				if nodes[wordId].word in sentWords:
								
					distances = [1.0/(abs(nodes[wordId].wordIndex - nodes[mentioned].wordIndex))]	
					for copy in range(6):
						targetMention = mentioned + '_' + str(copy)
						if targetMention in nodes:
							distance = 1/abs(nodes[wordId].wordIndex - nodes[targetMention].wordIndex)
							distances.append(distance)
					mentionDistance = max(distances)
					
					wordSent = nodes[wordId].sentiment
					wordSent *= -1 if nodes[wordId].negated else 1
					
					sentimentExists = True
					
					## BUT Rules ##
					if 'but' in nodes and '.' in nodes:
						if nodes[wordId].wordIndex < nodes['.'].wordIndex and nodes['but'].wordIndex < nodes['.'].wordIndex and \
							nodes[wordId].wordIndex < nodes['but'].wordIndex:
							nodes[wordId].but = True
							wordSent *=-1
						elif nodes[wordId].wordIndex > nodes['.'].wordIndex and nodes['but'].wordIndex > nodes['.'].wordIndex and \
							nodes[wordId].wordIndex < nodes['but'].wordIndex:
							nodes[wordId].but = True
							wordSent *=-1
					elif 'but' in nodes and not '.' in nodes:
						if nodes[wordId].wordIndex < nodes['but'].wordIndex:
							nodes[wordId].but = True
							wordSent *=-1
						
					feature = nodes[wordId].word
					if nodes[wordId].but:
						feature = feature + '_but'
					if nodes[wordId].negated:
						feature = 'not_' + feature
						
					X[pairIndex][sentWordsInd[feature]] = mentionDistance
			tweetParse = {}
			nodes = {}
			tweetIndex += 1
		else:
			splitLine = line.replace(u'\u2019','\'').split('\t')
			wordIndex = int(splitLine[0])
			word = splitLine[1].lower()
			postag = splitLine[3]
			w_postag = tweeboPOSToWordnetPOS(postag)
			rel = int(splitLine[6])
			try:
				if not w_postag == -1 and not (word + '_' + w_postag) in lemmaDict:
					lemmaDict[word + '_' + w_postag] = wordnet_lemmatizer.lemmatize(word,pos = w_postag)
					word = lemmaDict[word + '_' + w_postag]
				elif not w_postag == -1:
					word = lemmaDict[word + '_' + w_postag]
			except UnicodeDecodeError:
				pdb.set_trace()
			wordIdentifier = word
			sentiment = 0
			
			if wordIdentifier in nodes:
				copy = 2
				while wordIdentifier + '_' + str(copy) in nodes:
					copy += 1
				wordIdentifier = wordIdentifier + '_' + str(copy)
			
			if targets[tweetIndex][0] in word:
				# handles cases such as @David_Cameron's
				wordIdentifier = targets[tweetIndex][0]
			if targets[tweetIndex][1] in word:
				wordIdentifier = targets[tweetIndex][1]
			if word in sentWords:
				sentiment = sentWords[word]	
			#if word in ['you','your','yours','yourself']:#,'he','him','his','himself','she','her','herself','hers']:
			#	wordIdentifier = targets[tweetIndex]
			

			nodes[wordIdentifier] = parseTree(wordIndex,word,None,[],postag,sentiment,negateNext)
			
			negateNext = False

			if NEGATION_RE.search(word):
				negateNext = True
			
			tweetParse[wordIdentifier] = {}
			tweetParse[wordIdentifier]['index'] = wordIndex
			tweetParse[wordIdentifier]['tag'] = postag
			tweetParse[wordIdentifier]['rel'] = rel

	fParse.close()
	savemat('Matrices/X_' + breakouts[i] + '.mat',{'X':X})
	del X
try:
	with codecs.open('lemmaDict.json','w',encoding = 'utf-8') as fw:
		json.dump(lemmaDict,fw,indent = 4)
except Exception as e:
	print(e)
	pdb.set_trace()
