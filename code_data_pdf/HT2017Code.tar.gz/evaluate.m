function [ precision_neg, recall_neg, fmeasure_neg, microF1,macroF1,predCount ] = evaluate( S_u, realLabels )
%EVALUATE Summary of this function goes here
%   Detailed explanation goes here
signAssignments = pickMaxU(S_u);
wrongWeights = [];
nn = 0; 
np = 0;
pn = 0;
pp = 0;
predCount = 0;
for i = 1:length(signAssignments)
    if (signAssignments(i) == 2) && (realLabels(i) == 2)
        pp = pp + 1;
        predCount = predCount + 1;
        continue
    end
    if (signAssignments(i) == 1) && (realLabels(i) == 2)
        pn = pn + 1;
        predCount = predCount + 1;
        continue
    end
    if (signAssignments(i) == 2) && (realLabels(i) == 1)
        np = np + 1;
        predCount = predCount + 1;
        continue
    end
    if (signAssignments(i) == 1) && (realLabels(i) == 1)
        nn = nn + 1;
        predCount = predCount + 1;
        continue
    end
end
precision_neg = nn/(nn + pn+eps);
recall_neg = nn/(nn + np+eps);
fmeasure_neg = 2*precision_neg*recall_neg/(precision_neg + recall_neg+eps);
precision_pos = pp/(pp + np+eps);
recall_pos = pp/(pp + pn+eps);
fmeasure_pos = 2*precision_pos*recall_pos/(precision_pos + recall_pos+eps);
microF1 = 2*fmeasure_pos*fmeasure_neg/(fmeasure_pos+fmeasure_neg+eps);
macroF1 = (fmeasure_pos + fmeasure_neg)/2;
acc = (pp + nn)/(pp+pn+np+nn+eps);
end

