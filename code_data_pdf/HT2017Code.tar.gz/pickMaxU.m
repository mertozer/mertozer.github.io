function[communities] = pickMaxU(U)
    [numberOfElements, ~] = size(U);
    communities = zeros(numberOfElements,1)-1;
    for i = 1:numberOfElements
        if U(i,1) == U(i,2)
            clusterI = floor(rand*2) + 1;
        else
            [~,clusterI] = max(U(i,:));
        end
        communities(i) = clusterI;
    end
end